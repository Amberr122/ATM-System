package bank;

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;


public class ChangePin {

	public static void main(String[] args) throws Exception{
		
		//Verifying user data vai code
		Scanner reader = new Scanner(new File("code.txt"));
		String code = reader.nextLine();
		System.out.println(code);
		
		JFrame f = new JFrame("ATM");
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0,400, 600);
		panel.setBackground(Color.LIGHT_GRAY);
		f.add(panel);
		
		JLabel l0 = new JLabel("");
		l0.setBounds(0, 0, 0, 0);
		l0.setFont(new Font("Time New Roman", Font.BOLD, 90));
		l0.setBackground(Color.LIGHT_GRAY);
		l0.setForeground(Color.WHITE);
		panel.add(l0);
		
		JLabel l1, l2, l3;
		JButton b1, b2, b0, b00;
		
		l3 = new JLabel("Change Pin");
		l3.setBounds(560, 20 ,300 ,90);
		l3.setFont(new Font("Time new Roman", Font.BOLD, 50));
		l3.setForeground(Color.BLACK);
		f.add(l3);
		
		l1 = new JLabel("Current Pin");
		l1.setBounds(540, 150 ,140 ,30);
		l1.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l1.setForeground(Color.BLACK);
		f.add(l1);
		
		final JTextField currentPin = new JTextField();
		currentPin.setBounds(540, 180, 300, 35);
		currentPin.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(currentPin);
		
		l2 = new JLabel("New Pin");
		l2.setBounds(540, 230 ,140 ,30);
		l2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l2.setForeground(Color.BLACK);
		f.add(l2);
		
		JTextField pin1 = new JPasswordField();
		pin1.setBounds(540, 260, 300, 35);
		pin1.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(pin1);
		
		l2 = new JLabel("Confirm Pin");
		l2.setBounds(540, 310 ,140 ,30);
		l2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l2.setForeground(Color.BLACK);
		f.add(l2);
	
		b0 = new JButton("Show");
		b0.setBounds(840, 260, 50, 35);
		b0.setActionCommand("Click");
		b0.setForeground(Color.red);
		b0.setBackground(Color.white);
		b0.setBorder(BorderFactory.createEmptyBorder());
		b0.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e)  {
				String s = e.getActionCommand();
				if(s.equals("Click")) {
					((JPasswordField) pin1).setEchoChar((char)0);
					pin1.setFont(new Font("Time new Roman", Font.PLAIN, 15));
					b0.setText("Hide");
					b0.setActionCommand("unClick");
				} 
				if(s.equals("unClick")) {
					((JPasswordField) pin1).setEchoChar('\u25cf');
					pin1.setFont(new Font("Time new Roman", Font.PLAIN, 6));
					b0.setText("Show");
					b0.setActionCommand("Click");
				}	
			}
		});
		f.add(b0);
		
		JTextField pin2 = new JPasswordField();
		pin2.setBounds(540, 340, 300, 35);
		pin2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(pin2);
		
		b00 = new JButton("Show");
		b00.setBounds(840, 340, 50, 35);
		b00.setActionCommand("Click");
		b00.setForeground(Color.red);
		b00.setBackground(Color.white);
		b00.setBorder(BorderFactory.createEmptyBorder());
		b00.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e)  {
				String s = e.getActionCommand();
				if(s.equals("Click")) {
					((JPasswordField) pin2).setEchoChar((char)0);
					pin2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
					b00.setText("Hide");
					b00.setActionCommand("unClick");
				} 
				if(s.equals("unClick")) {
					((JPasswordField) pin2).setEchoChar('\u25cf');
					pin2.setFont(new Font("Time new Roman", Font.PLAIN, 6));
					b00.setText("Show");
					b00.setActionCommand("Click");
				}	
			}
		});
		f.add(b00);
		
		b1 = new JButton("Back");
		b1.setBounds(540, 420, 140, 35);
		b1.setFont(new Font("Time new Roman", Font.BOLD, 14));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
				AccountInfo accountInfo = new AccountInfo();
				try {
					accountInfo.main(args);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}	
			}
		});
		f.add(b1);
		
		b2 = new JButton("Change");
		b2.setBounds(700, 420, 140, 35);
		b2.setFont(new Font("Time new Roman", Font.BOLD, 14));
		b2.setBackground(Color.red);
		b2.setForeground(Color.white);
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				File file = new File("data.txt");
				ArrayList<Data> data = new ArrayList<Data>();
				//when create file old data will be remove
				ObjectOutputStream oos = null;
				ObjectInputStream ois = null;

				//check is file is available
				if(file.isFile()) {
					try {
						//read from file
						ois = new ObjectInputStream(new FileInputStream(file));
						//load data into array list
						data = (ArrayList<Data>) ois.readObject();
						ois.close();
					}catch (Exception ae) {}
				}
				ListIterator li = data.listIterator();
				
				while(li.hasNext()) {
					Data d = (Data) li.next();
					
					if(d.phoneNumber.equals(code)) {

						try {
							if(pin1.getText().equals("") && pin2.getText().equals("") && currentPin.getText().equals("")) {
								throw new Exception("Please input all data!");
							} else if(pin1.getText().equals("") && pin2.getText().equals("")) {
								throw new Exception("Please input new pin!");
							} else if(!pin1.getText().equals(pin2.getText())) {
								throw new Exception("Both new pin must be the same!");
							} else if(!currentPin.getText().equals(d.pin)){
								throw new Exception("Your current pin is incorrect!");
							} else if(d.pin.equals(currentPin.getText())) {
								String newPin = pin1.getText();
								li.set(new Data(d.firstName, d.lastName, d.email, d.phoneNumber, d.money, newPin));
								
								try {
									oos = new ObjectOutputStream(new FileOutputStream(file));
									oos.writeObject(data);
									oos.close();
								} catch(Exception e1) {}
								
								JOptionPane.showMessageDialog(f, "Pin Changed!");
								
								f.setVisible(false);
								AccountInfo accountinfo = new AccountInfo();
								accountinfo.main(args);
							}
							
						} catch (Exception a) {
							JOptionPane.showMessageDialog(f, a.getMessage());
						}
						
					}
				}	
			}
			
		});
		f.add(b2);
		
		Container c = f.getContentPane();
		c.setBackground(Color.WHITE);
		f.setSize(1000, 600);
		f.setLayout(null);
		f.setVisible(true); // To display the frame
	}

}
