package bank;

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.ListIterator;

class Data implements Serializable{
	String firstName;
	String lastName;
	String email;
	String phoneNumber;
	double money;
	String pin;
	
	Data(String firstName, String lastName, String email, String phoneNumber, double money, String pin){
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.money = money;
		this.pin = pin;
	}
	
}

public class Register {

	public static void main(String[] args) {

		
		
		JFrame f = new JFrame("ATM");
		JPanel panel = new JPanel();
		panel.setBounds(0, 0,400, 600);
		panel.setBackground(Color.LIGHT_GRAY);
		f.add(panel);
		
		JLabel l0 = new JLabel("");
		l0.setBounds(0, 0, 0, 0);
		l0.setFont(new Font("Time New Roman", Font.BOLD, 90));
		l0.setBackground(Color.LIGHT_GRAY);
		l0.setForeground(Color.WHITE);
		panel.add(l0);
		
		JLabel l1, l2, l3, l4, l5, l6, l7;
		JButton b1, b2, b0;
		
		l1 = new JLabel("Register");
		l1.setBounds(610, 20 ,300 ,90);
		l1.setFont(new Font("Time new Roman", Font.BOLD, 50));
		l1.setForeground(Color.BLACK);
		f.add(l1);
		
		l3 = new JLabel("First Name");
		l3.setBounds(520, 150 ,140 ,30);
		l3.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l3.setForeground(Color.BLACK);
		f.add(l3);
		
		final JTextField fName = new JTextField();
		fName.setBounds(520, 180, 170, 35);
		fName.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(fName);
		
		l2 = new JLabel("Last Name");
		l2.setBounds(730, 150 ,140 ,30);
		l2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l2.setForeground(Color.BLACK);
		f.add(l2);
		
		final JTextField lName = new JTextField();
		lName.setBounds(730, 180, 170, 35);
		lName.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(lName);
		
		l4 = new JLabel("Email");
		l4.setBounds(520, 230 ,140 ,30);
		l4.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l4.setForeground(Color.BLACK);
		f.add(l4);
		
		JTextField email = new JTextField();
		email.setBounds(520, 260, 380, 35);
		email.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(email);
		
		l5 = new JLabel("Phone Number");
		l5.setBounds(520, 310 ,140 ,30);
		l5.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l5.setForeground(Color.BLACK);
		f.add(l5);
		
		JTextField phoneNumber = new JTextField();
		phoneNumber.setBounds(520, 340, 380, 35);
		phoneNumber.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(phoneNumber);
		
		l6 = new JLabel("Balance");
		l6.setBounds(520, 390 ,140 ,30);
		l6.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l6.setForeground(Color.BLACK);
		f.add(l6);
		
		JTextField money = new JTextField();
		money.setBounds(520, 420, 170, 35);
		money.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(money);
		
		l7 = new JLabel("Pin");
		l7.setBounds(730, 390 ,140 ,30);
		l7.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l7.setForeground(Color.BLACK);
		f.add(l7);
		
		final JTextField pin = new JTextField();
		pin.setBounds(730, 420, 170, 35);
		pin.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(pin);
		
		b1 = new JButton("Create");
		b1.setBounds(730, 490, 170, 35);
		b1.setFont(new Font("Time new Roman", Font.BOLD, 14));
		b1.setBackground(Color.RED);
		b1.setForeground(Color.white);
		b1.addActionListener(new ActionListener() {
			
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				File file = new File("data.txt");
				ArrayList<Data> data = new ArrayList<Data>();
				//when create file old data will be remove
				ObjectOutputStream oos = null;
				ObjectInputStream ois = null;

				//check is file is available
				if(file.isFile()) {
					try {
						//read from file
						ois = new ObjectInputStream(new FileInputStream(file));
						//load data into array list
						data = (ArrayList<Data>) ois.readObject();
						ois.close();
					}catch (Exception ae) {}
				}
				
				ListIterator li = data.listIterator();
				
				
				if(fName.getText().equals("") || lName.getText().equals("") || email.getText().equals("") 
				 || phoneNumber.getText().equals("") || money.getText().equals("")){
					JOptionPane.showMessageDialog(f, "Please input all information!");
				} else {
					
					try {
						if(!email.getText().contains("@")) {
							throw new Exception("Invalid email address!");
						}
						String[] parts = email.getText().split("@");
			            String domain = parts[1];
			            
			            if(!domain.contains(".")) {
			            	throw new Exception("Invalid email domain!");
			            }
			            if(money.getText().contains("-")) {
			            	throw new Exception("Please input positive number!");
			            }
			            
			            boolean found = false;
			            boolean found1 = false;
			            while(li.hasNext()) {
			            	Data d = (Data) li.next();
			            	if(d.phoneNumber.equals(phoneNumber.getText())) {
			            		found = true;
			            	} else if(d.email.equals(email.getText())) {
			            		found1 = true;
			            	}
			            }
			            if(found) {
			            	throw new Exception("This phone number is already in use!");
			            } else if(found1) {
			            	throw new Exception("This email is already in use!");
			            }
			            
			            data.add(new Data(fName.getText(), lName.getText(), email.getText(), phoneNumber.getText(), Integer.parseInt(money.getText()), pin.getText()));
						try {
							oos = new ObjectOutputStream(new FileOutputStream(file));
							oos.writeObject(data);
							oos.close();
						} catch(Exception e1) {}
						
						
						JOptionPane.showMessageDialog(f, "Account Created Successfully.");
						fName.setText("");
						lName.setText("");
						email.setText("");
						phoneNumber.setText("");
						money.setText("");
						
						f.setVisible(false);
						Login login = new Login();
						login.main(args);
			            
					} catch(Exception a) {
						JOptionPane.showMessageDialog(f, a.getMessage());
					}
				}
			}
		});
		f.add(b1);
		
		b2 = new JButton("Back");
		b2.setBounds(520, 490, 120, 35);
		b2.setFont(new Font("Time new Roman", Font.BOLD, 14));
		b2.setBackground(Color.BLACK);
		b2.setForeground(Color.white);
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
				Login login = new Login();
				login.main(args);
			}
			
		});
		f.add(b2);
		
		Container c = f.getContentPane();
		c.setBackground(Color.WHITE);
		f.setSize(1000, 600);
		f.setLayout(null);
		f.setVisible(true); // To display the frame

	}

}
