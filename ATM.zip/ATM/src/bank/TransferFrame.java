package bank;

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;


public class TransferFrame {

	public static void main(String[] args) throws Exception{
		
		//Verifying user data vai code
		Scanner reader = new Scanner(new File("code.txt"));
		String code = reader.nextLine();
		System.out.println(code);
		
		JFrame f = new JFrame("ATM");
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0,400, 600);
		panel.setBackground(Color.LIGHT_GRAY);
		f.add(panel);
		
		JLabel l0 = new JLabel("");
		l0.setBounds(0, 0, 0, 0);
		l0.setFont(new Font("Time New Roman", Font.BOLD, 90));
		l0.setBackground(Color.LIGHT_GRAY);
		l0.setForeground(Color.WHITE);
		panel.add(l0);
		
		JLabel l1, l2, l3;
		JButton b1, b2, b0, b00;
		
		l3 = new JLabel("Transfer");
		l3.setBounds(590, 20 ,300 ,90);
		l3.setFont(new Font("Time new Roman", Font.BOLD, 50));
		l3.setForeground(Color.BLACK);
		f.add(l3);
		
		l1 = new JLabel("Reciever");
		l1.setBounds(540, 150 ,140 ,30);
		l1.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l1.setForeground(Color.BLACK);
		f.add(l1);
		
		final JTextField receiver = new JTextField();
		receiver.setBounds(540, 180, 300, 35);
		receiver.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(receiver);
		
		l2 = new JLabel("Amount");
		l2.setBounds(540, 230 ,140 ,30);
		l2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l2.setForeground(Color.BLACK);
		f.add(l2);
		
		JTextField amount = new JTextField();
		amount.setBounds(540, 260, 300, 35);
		amount.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(amount);
		
		l2 = new JLabel("Confirm Pin");
		l2.setBounds(540, 310 ,140 ,30);
		l2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l2.setForeground(Color.BLACK);
		f.add(l2);
		
		JTextField pin2 = new JPasswordField();
		pin2.setBounds(540, 340, 300, 35);
		pin2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(pin2);
		
		b00 = new JButton("Show");
		b00.setBounds(840, 340, 50, 35);
		b00.setActionCommand("Click");
		b00.setForeground(Color.red);
		b00.setBackground(Color.white);
		b00.setBorder(BorderFactory.createEmptyBorder());
		b00.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e)  {
				String s = e.getActionCommand();
				if(s.equals("Click")) {
					((JPasswordField) pin2).setEchoChar((char)0);
					pin2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
					b00.setText("Hide");
					b00.setActionCommand("unClick");
				} 
				if(s.equals("unClick")) {
					((JPasswordField) pin2).setEchoChar('\u25cf');
					pin2.setFont(new Font("Time new Roman", Font.PLAIN, 6));
					b00.setText("Show");
					b00.setActionCommand("Click");
				}	
			}
		});
		f.add(b00);
		
		b1 = new JButton("Back");
		b1.setBounds(540, 420, 140, 35);
		b1.setFont(new Font("Time new Roman", Font.BOLD, 14));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
				Transaction trasaction = new Transaction();
				try {
					trasaction.main(args);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		f.add(b1);
		
		b2 = new JButton("Confirm");
		b2.setBounds(700, 420, 140, 35);
		b2.setFont(new Font("Time new Roman", Font.BOLD, 14));
		b2.setBackground(Color.red);
		b2.setForeground(Color.white);
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				File file = new File("data.txt");
				ArrayList<Data> data = new ArrayList<Data>();
				//when create file old data will be remove
				ObjectOutputStream oos = null;
				ObjectInputStream ois = null;

				//check is file is available
				if(file.isFile()) {
					try {
						//read from file
						ois = new ObjectInputStream(new FileInputStream(file));
						//load data into array list
						data = (ArrayList<Data>) ois.readObject();
						ois.close();
					}catch (Exception ae) {}
				}
				ListIterator li = data.listIterator();
				while(li.hasNext()) {
					Data d = (Data) li.next();
					if(d.phoneNumber.equals(code)) {
						try {
							double a = Double.parseDouble(amount.getText());
							double newBalance = d.money - a;
							
							if(receiver.getText().equals("") && amount.getText().equals("") && pin2.getText().equals("")) {
								throw new Exception("Please enter all information!");
							} else if(newBalance < 0) {
								throw new Exception("You don't have enough money!");
							} else if(a < 0) {
								throw new Exception("Money can't be negative!");
							} else if(!d.pin.equals(pin2.getText())) {
								throw new Exception("Wrong pin!");	
							} else if(receiver.getText().equals(d.phoneNumber)) {
								throw new Exception("You can't transfer to your own account!");
							}
							
							li.set(new Data(d.firstName, d.lastName, d.email, d.phoneNumber, newBalance, d.pin));
							
							//find receiver
							ListIterator l = data.listIterator();
							boolean found = false;
							while(l.hasNext()) {
								Data d0 = (Data) l.next();
								if(d0.phoneNumber.equals(receiver.getText())) {
									double a0 = Double.parseDouble(amount.getText());
									double newBalance1 = d0.money + a0;
									l.set(new Data(d0.firstName, d0.lastName, d0.email, d0.phoneNumber, newBalance1, d0.pin));
									found = true;
								}
							}
							
							if(found) {
								try {
									oos = new ObjectOutputStream(new FileOutputStream(file));
									oos.writeObject(data);
									oos.close();
								} catch(Exception e1) {}
								JOptionPane.showMessageDialog(f, "You have successfully sent!");
								
								pin2.setText("");
								amount.setText("");
								receiver.setText("");
								
							} else if(!found) {
								JOptionPane.showMessageDialog(f, "Receiver not found!");
							}
	
						} catch (Exception a) {
							JOptionPane.showMessageDialog(f, a.getMessage());
						}
					} 
				}
	
			}
			
		});
		f.add(b2);
		
		Container c = f.getContentPane();
		c.setBackground(Color.WHITE);
		f.setSize(1000, 600);
		f.setLayout(null);
		f.setVisible(true); // To display the frame
	}

}
