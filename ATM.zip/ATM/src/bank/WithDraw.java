package bank;

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

public class WithDraw {

	
	public static void main(String[] args) throws Exception{
		
		//Verifying user data vai code
		Scanner reader = new Scanner(new File("code.txt"));
		String code = reader.nextLine();
		System.out.println(code);
		
		
		JFrame f = new JFrame("ATM");
		JLabel l1, l2, l3, l4, l5, l6;
		JButton b0, b1, b2, b3, b4, b5, b6, b7, b8;
		
		l1 = new JLabel("Withdraw");
		l1.setBounds(25, 20, 180, 30);
		l1.setFont(new Font("Time new Roman", Font.BOLD, 35));
		l1.setForeground(Color.black);
		f.add(l1);
		
		
		b0 = new JButton("Card Return");
		b0.setBounds(800, 20, 150, 30);
		b0.setFont(new Font("Time new Roman", Font.PLAIN, 20));
		b0.setBackground(Color.WHITE);
		b0.setForeground(Color.GRAY);
		b0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		b0.setBorder(BorderFactory.createEmptyBorder());
		f.add(b0);
		
		File file = new File("data.txt");
		ArrayList<Data> data = new ArrayList<Data>();
		ObjectInputStream ois = null;
		ObjectOutputStream oos = null;
		//check is file is available
		if(file.isFile()) {
			try {
				//read from file
				ois = new ObjectInputStream(new FileInputStream(file));
				//load data into array list
				data = (ArrayList<Data>) ois.readObject();
				ois.close();
			}catch (Exception ae) {}
		}
		ListIterator li = data.listIterator();
		
		while(li.hasNext()) {
			
			Data d = (Data) li.next();
			if(d.phoneNumber.equals(code)) {
				
				System.out.println();
				System.out.println(li.previousIndex());
				int count = 1;
				
				l3 = new JLabel("Balance");
				l3.setBounds(25, 120, 80, 30);
				l3.setFont(new Font("Time new Roman", Font.PLAIN, 15));
				l3.setForeground(Color.DARK_GRAY);
				f.add(l3);
				
				DecimalFormat df = new DecimalFormat("#,###.00");
				String formattedNumber = df.format(d.money);
				
				l4 = new JLabel("$ " + formattedNumber);
				l4.setBounds(25, 150, 150, 30);
				l4.setFont(new Font("Time new Roman", Font.BOLD, 25));
				l4.setForeground(Color.BLACK);
				f.add(l4);
				
				final JTextField withdraw = new JTextField();
				withdraw.setBounds(370, 120, 580, 60);
				withdraw.setFont(new Font("Time new Roman", Font.PLAIN, 25));
				f.add(withdraw);
				
				b3 = new JButton("$ 20");
				b3.setBounds(370, 230, 280, 70);
				b3.setFont(new Font("Time new Roman", Font.PLAIN, 30));
				b3.setBackground(Color.black);
				b3.setForeground(Color.white);
				b3.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						String value = "20";
						withdraw.setText(value);
					}
				});
				f.add(b3);
				
				b4 = new JButton("$ 50");
				b4.setBounds(670, 230, 280, 70);
				b4.setFont(new Font("Time new Roman", Font.PLAIN, 30));
				b4.setBackground(Color.black);
				b4.setForeground(Color.white);
				b4.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						withdraw.setText("50");
					}
				});
				f.add(b4);
				
				b5 = new JButton("$ 100");
				b5.setBounds(370, 320, 280, 70);
				b5.setFont(new Font("Time new Roman", Font.PLAIN, 30));
				b5.setBackground(Color.black);
				b5.setForeground(Color.white);
				b5.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						withdraw.setText("100");
					}
				});
				f.add(b5);
				
				b6 = new JButton("$ 200");
				b6.setBounds(670, 320, 280, 70);
				b6.setFont(new Font("Time new Roman", Font.PLAIN, 30));
				b6.setBackground(Color.BLACK);
				b6.setForeground(Color.white);
				b6.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						withdraw.setText("200");
					}
				});
				f.add(b6);
				
				b7 = new JButton("WITHDRAW");
				b7.setBounds(790, 440, 160, 60);
				b7.setFont(new Font("Time new Roman", Font.BOLD, 20));
				b7.setForeground(Color.WHITE);
				b7.setBackground(Color.PINK);
				b7.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						if(withdraw.getText().equals("")) {
							JOptionPane.showMessageDialog(f, "Please enter amount of money");
						} else {
							
							File file = new File("data.txt");
							ArrayList<Data> data = new ArrayList<Data>();
							ObjectInputStream ois = null;
							ObjectOutputStream oos = null;
							//check is file is available
							if(file.isFile()) {
								try {
									//read from file
									ois = new ObjectInputStream(new FileInputStream(file));
									//load data into array list
									data = (ArrayList<Data>) ois.readObject();
									ois.close();
								}catch (Exception ae) {}
							}
							
							ListIterator li = data.listIterator();
							
							while(li.hasNext()) {
								Data d = (Data) li.next();
								if(d.phoneNumber.equals(code)) {
									try {

										double a = Double.parseDouble(withdraw.getText());
										double new_balance = d.money - a;
										
										if(a < 0) {
											throw new Exception("Please input positive number!");
										} else if (a > 50000) {
											throw new Exception("WithDraw limit is 50K");
										} else if(new_balance < 0) {
											throw new Exception("You don't have enogh money");
										} 
							
										li.set(new Data(d.firstName, d.lastName, d.email, d.phoneNumber, new_balance, d.pin));
										
										try {
											oos = new ObjectOutputStream(new FileOutputStream(file));
											oos.writeObject(data);
											oos.close();
										} catch(Exception e1) {}
										
										withdraw.setText("");
										JOptionPane.showMessageDialog(f, "Withdrawal Successful!");
										
										f.setVisible(false);
										WithDraw withdraw0 = new WithDraw();
										try {
											withdraw0.main(args);
										} catch (Exception e1) {
											e1.printStackTrace();
										}
										
									} catch (Exception ae) {
										JOptionPane.showMessageDialog(f, ae.getMessage());
										withdraw.setText("");
									}
								}
							}
							

						}
						
					}
				});
				f.add(b7);
			}
		}
		
		
		
		b8 = new JButton("Back");
		b8.setBounds(20, 515, 90, 30);
		b8.setFont(new Font("Time new Roman", Font.BOLD, 17));
		b8.setForeground(Color.WHITE);
		b8.setBackground(Color.RED);
		b8.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
				Transaction transaction = new Transaction();
				try {
					transaction.main(args);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		f.add(b8);
		
		Container c = f.getContentPane();
		c.setBackground(Color.WHITE);
		
		f.setSize(1000, 600);
		f.setLayout(null);
		f.setVisible(true); // To display the frame
		
	}

}








