package bank;

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;



public class Transaction {
	
	public static void main(String[] args) throws Exception{
		
		//Verifying user data vai code
		Scanner reader = new Scanner(new File("code.txt"));
		String code = reader.nextLine();
		System.out.println(code);
		
		//creating new frame
		JFrame f = new JFrame("ATM");
		JLabel l1, l2, l3, l4, l5, l6;
		JButton b0, b1, b2, b3, b4, b5, b6, b7, b8;
		
		l1 = new JLabel("ATM");
		l1.setBounds(25, 20, 80, 30);
		l1.setFont(new Font("Time new Roman", Font.BOLD, 35));
		l1.setForeground(Color.black);
		f.add(l1);
		
		
		b0 = new JButton("Card Return");
		b0.setBounds(800, 20, 150, 30);
		b0.setFont(new Font("Time new Roman", Font.PLAIN, 20));
		b0.setBackground(Color.WHITE);
		b0.setForeground(Color.GRAY);
		b0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		b0.setBorder(BorderFactory.createEmptyBorder());
		f.add(b0);
		
		l2 = new JLabel("Card Return");
		l2.setBounds(840, 20, 120, 30);
		l2.setFont(new Font("Time new Roman", Font.PLAIN, 20));
		l2.setForeground(Color.DARK_GRAY);
		f.add(l2);
		
		l3 = new JLabel("Welcome");
		l3.setBounds(25, 120, 80, 30);
		l3.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l3.setForeground(Color.DARK_GRAY);
		f.add(l3);
		
		File file = new File("data.txt");
		ArrayList<Data> data = new ArrayList<Data>();
		ObjectInputStream ois = null;
		ObjectOutputStream oos = null;
		//check is file is available
		if(file.isFile()) {
			try {
				//read from file
				ois = new ObjectInputStream(new FileInputStream(file));
				//load data into array list
				data = (ArrayList<Data>) ois.readObject();
				ois.close();
			}catch (Exception ae) {}
		}
		ListIterator li = data.listIterator();
		
		while(li.hasNext()) {
			Data d = (Data) li.next();
			if(d.phoneNumber.equals(code)) {
				l4 = new JLabel(d.firstName + " " + d.lastName);
				l4.setBounds(25, 150, 250, 40);
				l4.setFont(new Font("Time new Roman", Font.BOLD, 25));
				l4.setForeground(Color.BLACK);
				f.add(l4);
				
				DecimalFormat df = new DecimalFormat("#,###.00");
				String formattedNumber = df.format(d.money);
				
				l6 = new JLabel("$ " + formattedNumber);
				l6.setBounds(25, 230, 150, 40);
				l6.setFont(new Font("Time new Roman", Font.BOLD, 25));
				l6.setForeground(Color.BLACK);
				f.add(l6);
				
				b7 = new JButton("10$ Quick Cash");
				b7.setBounds(670, 440, 280, 50);
				b7.setFont(new Font("Time new Roman", Font.BOLD, 20));
				b7.setForeground(Color.WHITE);
				b7.setBackground(Color.PINK);
				b7.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						File file = new File("data.txt");
						ArrayList<Data> data = new ArrayList<Data>();
						ObjectOutputStream oos = null;
						
						double new_balance = d.money - 10;
						
						data.add(new Data(d.firstName, d.lastName, d.email, d.phoneNumber, new_balance, d.pin));
						try {
							oos = new ObjectOutputStream(new FileOutputStream(file));
							oos.writeObject(data);
							oos.close();
						} catch(Exception e1) {}
						
						JOptionPane.showMessageDialog(f, "Deposit Successful!");
						
						f.setVisible(false);
						Transaction transaction = new Transaction();
						try {
							transaction.main(args);
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				});
				f.add(b7);
			}
		}
		
		
		l5 = new JLabel("Balance");
		l5.setBounds(25, 200, 80, 30);
		l5.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l5.setForeground(Color.DARK_GRAY);
		f.add(l5);
		
		b1 = new JButton("Get Cash");
		b1.setBounds(370, 120, 280, 70);
		b1.setFont(new Font("Time new Roman", Font.PLAIN, 20));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
				WithDraw withdraw = new WithDraw();
				try {
					withdraw.main(args);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		f.add(b1);
		
		b2 = new JButton("Desposit");
		b2.setBounds(670, 120, 280, 70);
		b2.setFont(new Font("Time new Roman", Font.PLAIN, 20));
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
				Deposit deposit = new Deposit();
				try {
					deposit.main(args);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			
		});
		f.add(b2);
		
		b3 = new JButton("Transfer");
		b3.setBounds(370, 210, 280, 70);
		b3.setFont(new Font("Time new Roman", Font.PLAIN, 20));
		b3.setBackground(Color.black);
		b3.setForeground(Color.white);
		b3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				f.setVisible(false);
				TransferFrame transfer = new TransferFrame();
				try {
					transfer.main(args);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		f.add(b3);
		
		b4 = new JButton("Creadit Card");
		b4.setBounds(670, 210, 280, 70);
		b4.setFont(new Font("Time new Roman", Font.PLAIN, 20));
		b4.setBackground(Color.black);
		b4.setForeground(Color.white);
		f.add(b4);
		
		b5 = new JButton("Account Setting");
		b5.setBounds(370, 300, 280, 70);
		b5.setFont(new Font("Time new Roman", Font.PLAIN, 20));
		b5.setBackground(Color.black);
		b5.setForeground(Color.white);
		b5.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
				AccountInfo accountInfo = new AccountInfo();
				try {
					accountInfo.main(args);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		f.add(b5);
		
		b6 = new JButton("Other");
		b6.setBounds(670, 300, 280, 70);
		b6.setFont(new Font("Time new Roman", Font.PLAIN, 20));
		b6.setBackground(Color.gray);
		b6.setForeground(Color.white);
		f.add(b6);
		
		
		
		b8 = new JButton("Sing Out");
		b8.setBounds(20, 515, 120, 30);
		b8.setFont(new Font("Time new Roman", Font.BOLD, 17));
		b8.setForeground(Color.WHITE);
		b8.setBackground(Color.RED);
		b8.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				f.setVisible(false);
				Login login = new Login();
				login.main(args);
				
			}
			
		});
		f.add(b8);
		
		Container container = f.getContentPane();
		container.setBackground(Color.WHITE);
		
		f.setSize(1000, 600);
		f.setLayout(null);
		f.setVisible(true); // To display the frame
		
	}

}
