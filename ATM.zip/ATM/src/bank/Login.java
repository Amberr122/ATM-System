package bank;

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.ListIterator;


public class Login {

	public static void main(String[] args) {
		
		JFrame f = new JFrame("ATM");
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0,400, 600);
		panel.setBackground(Color.LIGHT_GRAY);
		f.add(panel);
		
		JLabel l0 = new JLabel("");
		l0.setBounds(0, 0, 0, 0);
		l0.setFont(new Font("Time New Roman", Font.BOLD, 90));
		l0.setBackground(Color.LIGHT_GRAY);
		l0.setForeground(Color.WHITE);
		panel.add(l0);
		
		JLabel l1, l2, l3;
		JButton b1, b2, b0;
		
		l3 = new JLabel("Login");
		l3.setBounds(630, 20 ,300 ,90);
		l3.setFont(new Font("Time new Roman", Font.BOLD, 50));
		l3.setForeground(Color.BLACK);
		f.add(l3);
		
		l1 = new JLabel("Phone Number");
		l1.setBounds(540, 150 ,140 ,30);
		l1.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l1.setForeground(Color.BLACK);
		f.add(l1);
		
		final JTextField number = new JTextField();
		number.setBounds(540, 180, 300, 35);
		number.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(number);
		
		l2 = new JLabel("Pin");
		l2.setBounds(540, 230 ,140 ,30);
		l2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		l2.setForeground(Color.BLACK);
		f.add(l2);
		
		JTextField password = new JPasswordField();
		password.setBounds(540, 260, 300, 35);
		password.setFont(new Font("Time new Roman", Font.PLAIN, 15));
		f.add(password);
		
		b0 = new JButton("Show");
		b0.setBounds(840, 260, 70, 35);
		b0.setActionCommand("Click");
		b0.setForeground(Color.red);
		b0.setBackground(Color.white);
		b0.setBorder(BorderFactory.createEmptyBorder());
		b0.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e)  {
				String s = e.getActionCommand();
				if(s.equals("Click")) {
					((JPasswordField) password).setEchoChar((char)0);
					password.setFont(new Font("Time new Roman", Font.PLAIN, 15));
					b0.setText("Hide");
					b0.setActionCommand("unClick");
				} 
				if(s.equals("unClick")) {
					((JPasswordField) password).setEchoChar('\u25cf');
					password.setFont(new Font("Time new Roman", Font.PLAIN, 6));
					b0.setText("Show");
					b0.setActionCommand("Click");
				}	
			}
		});
		f.add(b0);
		
		b1 = new JButton("Sign In");
		b1.setBounds(540, 320, 140, 35);
		b1.setFont(new Font("Time new Roman", Font.BOLD, 14));
		b1.setBackground(Color.black);
		b1.setForeground(Color.white);
		b1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {
					if(number.getText().equals("") && password.getText().equals("")) {
						throw new Exception("Please enter number & pin");
					} else if(number.getText().equals("")) {
						throw new Exception("Please enter number");
					} else if(password.getText().equals("")) {
						throw new Exception("Please enter pin");
					}
					
					File file = new File("data.txt");
					ArrayList<Data> data = new ArrayList<Data>();
					ObjectInputStream ois = null;
					ObjectOutputStream oos = null;
					//check is file is available
					if(file.isFile()) {
						try {
							//read from file
							ois = new ObjectInputStream(new FileInputStream(file));
							//load data into array list
							data = (ArrayList<Data>) ois.readObject();
							ois.close();
						}catch (Exception ae) {}
					}
					boolean found = false;
					boolean found1 = false;
					ListIterator li = null;
					li = data.listIterator();
					while(li.hasNext()) {
						Data d = (Data) li.next();
						
						if(d.phoneNumber.equals(number.getText()) && d.pin.equals(password.getText())) {
							
							PrintWriter writer = new PrintWriter("code.txt");
							writer.println(d.phoneNumber);
							writer.close();
							
							f.setVisible(false);
							Transaction transaction = new Transaction();
							transaction.main(args);
							found = true;
						} else if (d.phoneNumber.equals(number.getText()) && !d.pin.equals(password.getText())) {
							found1 = true;
						}
					}
					
					if(!found && !found1) {
						JOptionPane.showMessageDialog(f, "User not found!");
					} else if(found1) {
						JOptionPane.showMessageDialog(f, "Your pin is incorrect!");
					}
					
				} catch (Exception a) {
					JOptionPane.showMessageDialog(f, a.getMessage());
				}
						
			}
			
		});
		f.add(b1);
		
		b2 = new JButton("Sign Up");
		b2.setBounds(700, 320, 140, 35);
		b2.setFont(new Font("Time new Roman", Font.BOLD, 14));
		b2.setBackground(Color.black);
		b2.setForeground(Color.white);
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				f.setVisible(false);
				Register register = new Register();
				register.main(args);
			}
			
		});
		f.add(b2);
		
		Container c = f.getContentPane();
		c.setBackground(Color.WHITE);
		f.setSize(1000, 600);
		f.setLayout(null);
		f.setVisible(true); // To display the frame
	}

}
