package bank;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;


public class MiniStatement extends JFrame implements ActionListener {

    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField ageField;
    private JTextField majorField;
    private JTable table;
    private DefaultTableModel tableModel;

    public MiniStatement() {
        // Create the components
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameField = new JTextField();
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameField = new JTextField();
        JLabel ageLabel = new JLabel("Age:");
        ageField = new JTextField();
        JLabel majorLabel = new JLabel("Major:");
        majorField = new JTextField();
        JButton addButton = new JButton("Add");
        tableModel = new DefaultTableModel(new String[]{"First Name", "Last Name", "Age", "Major"}, 0);
        table = new JTable(tableModel);

        // Create the layout
        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
        inputPanel.add(firstNameLabel);
        inputPanel.add(firstNameField);
        inputPanel.add(lastNameLabel);
        inputPanel.add(lastNameField);
        inputPanel.add(ageLabel);
        inputPanel.add(ageField);
        inputPanel.add(majorLabel);
        inputPanel.add(majorField);
        inputPanel.add(addButton);
        addButton.addActionListener(this);

        JScrollPane tableScrollPane = new JScrollPane(table);
        tableScrollPane.setPreferredSize(new Dimension(400, 200));

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);

        // Set the frame properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Student Information");
        setPreferredSize(new Dimension(600, 400));
        add(mainPanel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new MiniStatement();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String age = ageField.getText();
        String major = majorField.getText();

        Object[] rowData = {firstName, lastName, age, major};
        tableModel.addRow(rowData);

        firstNameField.setText("");
        lastNameField.setText("");
        ageField.setText("");
        majorField.setText("");
    }
}
