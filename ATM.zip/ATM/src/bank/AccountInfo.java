package bank;

import javax.swing.*;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;


public class AccountInfo {

	public static void main(String[] args) throws Exception{

		//Verifying user data vai code
		Scanner reader = new Scanner(new File("code.txt"));
		String code = reader.nextLine();
		System.out.println(code);
		
		JFrame f = new JFrame("ATM");
		JLabel l0, l1, l2, l3, l4, l5, l6, l7, l10, l20, l30, l40, l50, l60;
		JButton b1, b2, b0;
		
		l0 = new JLabel("Account Setting");
		l0.setBounds(330, 20 ,400 ,90);
		l0.setFont(new Font("Time new Roman", Font.BOLD, 40));
		l0.setForeground(Color.BLACK);
		f.add(l0);
		
		File file = new File("data.txt");
		ArrayList<Data> data = new ArrayList<Data>();
		ObjectInputStream ois = null;
		ObjectOutputStream oos = null;
		//check is file is available
		if(file.isFile()) {
			try {
				//read from file
				ois = new ObjectInputStream(new FileInputStream(file));
				//load data into array list
				data = (ArrayList<Data>) ois.readObject();
				ois.close();
			}catch (Exception ae) {}
		}
		ListIterator li = data.listIterator();
		
		while(li.hasNext()) {
			Data d = (Data) li.next();
			if(d.phoneNumber.equals(code)) {
				
				l1 = new JLabel("First Name");
				l1.setBounds(90, 150 ,140 ,30);
				l1.setFont(new Font("Time new Roman", Font.PLAIN, 15));
				l1.setForeground(Color.BLACK);
				f.add(l1);
				
				l10 = new JLabel(d.firstName);
				l10.setBounds(90, 180, 170, 35);
				l10.setFont(new Font("Time new Roman", Font.BOLD, 25));
				l10.setForeground(Color.BLACK);
				f.add(l10);
				
				l2 = new JLabel("Last Name");
				l2.setBounds(250, 150 ,140 ,30);
				l2.setFont(new Font("Time new Roman", Font.PLAIN, 15));
				l2.setForeground(Color.BLACK);
				f.add(l2);
				
				l20 = new JLabel(d.lastName);
				l20.setBounds(250, 180, 170, 35);
				l20.setFont(new Font("Time new Roman", Font.BOLD, 25));
				l20.setForeground(Color.BLACK);
				f.add(l20);
				
				l3 = new JLabel("Balance");
				l3.setBounds(90, 240 ,140 ,30);
				l3.setFont(new Font("Time new Roman", Font.PLAIN, 15));
				l3.setForeground(Color.BLACK);
				f.add(l3);
				
				DecimalFormat df = new DecimalFormat("#,###.00");
				String formattedNumber = df.format(d.money);
				l30 = new JLabel("$ " + formattedNumber);
				l30.setBounds(90, 270 ,240 ,30);
				l30.setFont(new Font("Time new Roman", Font.BOLD, 25));
				l30.setForeground(Color.BLACK);
				f.add(l30);
				
				l4 = new JLabel("Phone Number");
				l4.setBounds(90, 330 ,140 ,30);
				l4.setFont(new Font("Time new Roman", Font.PLAIN, 15));
				l4.setForeground(Color.BLACK);
				f.add(l4);
				
				l4 = new JLabel(d.phoneNumber);
				l4.setBounds(90, 360 ,140 ,30);
				l4.setFont(new Font("Time new Roman", Font.BOLD, 25));
				l4.setForeground(Color.BLACK);
				f.add(l4);
				
				l5 = new JLabel("Email");
				l5.setBounds(560, 150 ,140 ,30);
				l5.setFont(new Font("Time new Roman", Font.PLAIN, 15));
				l5.setForeground(Color.BLACK);
				f.add(l5);
				
				l50 = new JLabel(d.email);
				l50.setBounds(560, 180 ,340 ,30);
				l50.setFont(new Font("Time new Roman", Font.BOLD, 25));
				l50.setForeground(Color.BLACK);
				f.add(l50);
				
				l6 = new JLabel("Pin");
				l6.setBounds(560, 240 ,140 ,30);
				l6.setFont(new Font("Time new Roman", Font.PLAIN, 15));
				l6.setForeground(Color.BLACK);
				f.add(l6);
				
				
				l60 = new JLabel(d.pin);
				l60.setBounds(560, 270 ,340 ,30);
				l60.setFont(new Font("Time new Roman", Font.BOLD, 25));
				l60.setForeground(Color.BLACK);
				f.add(l60);
				
				
			}
		}
		
		b1 = new JButton("Change Pin");
		b1.setBounds(560, 320, 170, 35);
		b1.setFont(new Font("Time new Roman", Font.BOLD, 15));
		b1.setBackground(Color.RED);
		b1.setForeground(Color.white);
		b1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
				ChangePin changepin = new ChangePin();
				try {
					changepin.main(args);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
			
		});
		f.add(b1);
		
		b2 = new JButton("Back");
		b2.setBounds(20, 515, 120, 35);
		b2.setFont(new Font("Time new Roman", Font.BOLD, 14));
		b2.setBackground(Color.BLACK);
		b2.setForeground(Color.white);
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
				Transaction transaction = new Transaction();
				try {
					transaction.main(args);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		f.add(b2);
		
		Container c = f.getContentPane();
		c.setBackground(Color.WHITE);
		f.setSize(1000, 600);
		f.setLayout(null);
		f.setVisible(true); // To display the frame

	}

}
