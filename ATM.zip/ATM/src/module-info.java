/**
 * 
 */
/**
 * @author koysa
 *
 */
module ATM {
	requires java.desktop;
}